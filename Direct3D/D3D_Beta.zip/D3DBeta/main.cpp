#include <d3d9.h>
#include <d3dx9.h>
#define D3DFVF_CUSTOMVERTEX (D3DFVF_XYZ|D3DFVF_NORMAL|D3DFVF_TEX1)

/*------------------------------------------------------------------------------
 * ��������
 *------------------------------------------------------------------------------
 */
LPDIRECT3D9             g_pD3D = NULL;
LPDIRECT3DDEVICE9       g_pd3dDevice = NULL;
LPDIRECT3DVERTEXBUFFER9  g_pVB = NULL;
LPDIRECT3DINDEXBUFFER9 g_pIB = NULL;
LPDIRECT3DVERTEXBUFFER9  air = NULL;
LPDIRECT3DINDEXBUFFER9 cloud = NULL;
LPDIRECT3DTEXTURE9 g_ppTexture = NULL;
LPDIRECT3DTEXTURE9 g_ppTexture1 = NULL;
LPDIRECT3DTEXTURE9 g_ppTexture2 = NULL;

void __KeyProc();

struct CUSTOMVERTEX
{
	D3DXVECTOR3 position;
	D3DXVECTOR3 normal;
	FLOAT tu, tv;
};

struct DXUT_SCREEN_VERTEX
{
	float x, y, z, h;
	D3DCOLOR color;
	float tu, tv;

	static DWORD FVF;
};
DWORD DXUT_SCREEN_VERTEX::FVF = D3DFVF_XYZRHW | D3DFVF_DIFFUSE | D3DFVF_TEX1;

D3DXVECTOR3 Player = { 0,0,0 };
D3DXVECTOR3 Direction = { 0,0,0 };
float tx = 0.0f;
float ty = 0.0f;
float tz = 0.0f;

D3DXMATRIX tempViewTM;

/*------------------------------------------------------------------------------
 * Direct3D �ʱ�ȭ : �ڼ��� ������� �� ���� �߿��� �Լ�.
 *------------------------------------------------------------------------------
 */
HRESULT InitD3D(HWND hWnd)
{
	// ����̽��� �����ϱ����� D3D��ü ����
	if (NULL == (g_pD3D = Direct3DCreate9(D3D_SDK_VERSION)))
		return E_FAIL;
	D3DPRESENT_PARAMETERS d3dpp;
	ZeroMemory(&d3dpp, sizeof(d3dpp));
	d3dpp.Windowed = TRUE;
	d3dpp.SwapEffect = D3DSWAPEFFECT_DISCARD;
	d3dpp.BackBufferFormat = D3DFMT_UNKNOWN;
	d3dpp.BackBufferFormat = D3DFMT_X8R8G8B8;
	d3dpp.BackBufferWidth = 1024;
	d3dpp.BackBufferHeight = 768;
	d3dpp.BackBufferCount = 2;

	d3dpp.Flags = D3DPRESENTFLAG_VIDEO;
	d3dpp.EnableAutoDepthStencil = TRUE;
	d3dpp.AutoDepthStencilFormat = D3DFMT_D24S8;

	if (FAILED(g_pD3D->CreateDevice(D3DADAPTER_DEFAULT,
		D3DDEVTYPE_HAL,
		hWnd,
		D3DCREATE_SOFTWARE_VERTEXPROCESSING,
		&d3dpp,
		&g_pd3dDevice)))
	{
		return E_FAIL;
	}

	// ����̽� ���������� ó���Ұ�� ���⿡�� �Ѵ�.
	g_pd3dDevice->SetRenderState(D3DRS_LIGHTING, TRUE);
	g_pd3dDevice->SetRenderState(D3DRS_SPECULARENABLE, TRUE);
	return S_OK;
}

VOID Cleanup()
{
	// ���� ����. ������ �ݵ�� ���� ������ �������� ���� ���� ��. 

	if (g_ppTexture2 != NULL)g_ppTexture2->Release();
	if (g_ppTexture1 != NULL)g_ppTexture1->Release();
	if (g_ppTexture != NULL)g_ppTexture->Release();
	if (cloud != NULL)cloud->Release();
	if (air != NULL)air->Release();
	if (g_pIB != NULL)g_pIB->Release();
	if (g_pVB != NULL)g_pVB->Release();
	if (g_pd3dDevice != NULL)g_pd3dDevice->Release();
	if (g_pD3D != NULL)g_pD3D->Release();
}
void DrawLight()
{
	D3DLIGHT9 d3dLight;
	ZeroMemory(&d3dLight, sizeof(D3DLIGHT9));
	d3dLight.Type = D3DLIGHT_DIRECTIONAL;

	d3dLight.Diffuse.r = 5.0f;
	d3dLight.Diffuse.g = 5.0f;
	d3dLight.Diffuse.b = 5.0f;

	D3DXVECTOR3 vecDir = { -30, 30, -30 };
	D3DXVec3Normalize((D3DXVECTOR3*)&d3dLight.Direction, &vecDir);
	D3DMATERIAL9 d3dMaterial;
	ZeroMemory(&d3dMaterial, sizeof(D3DMATERIAL9));

	d3dMaterial.Diffuse.r = d3dMaterial.Ambient.r = 1.0f;
	d3dMaterial.Diffuse.g = d3dMaterial.Ambient.g = 1.0f;
	d3dMaterial.Diffuse.b = d3dMaterial.Ambient.b = 0.85f;
	d3dMaterial.Diffuse.a = d3dMaterial.Ambient.a = 1.0f;

	d3dMaterial.Specular.r = 0.5f;
	d3dMaterial.Specular.g = 0.5f;
	d3dMaterial.Specular.b = 0.5f;
	d3dMaterial.Specular.a = 0.5f;

	d3dMaterial.Power = 0.7f;

	g_pd3dDevice->SetLight(0, &d3dLight);
	g_pd3dDevice->LightEnable(0, TRUE);
	g_pd3dDevice->SetMaterial(&d3dMaterial);
}

void DrawPlayer()
{
	D3DXMATRIX TM0, TM1, TM2, TM3;

	//�ڽ� ��ġ
	D3DXMatrixTranslation(&TM0, 0, 0, -0.55f);
	//ȸ��
	D3DXMatrixRotationYawPitchRoll(&TM1, tx, ty, tz);
	//�̵�
	D3DXMatrixTranslation(&TM2, Player.x, Player.y, Player.z);

	//���ӵ�
	D3DXVECTOR3 temp;
	D3DXVec3TransformCoord(&temp, &Direction, &TM1);
	D3DXMatrixTranslation(&TM3, temp.x, temp.y, temp.z);
	Player += temp;

	//���� ��ġ��

	D3DXMatrixMultiply(&TM0, &TM0, &TM1);
	D3DXMatrixMultiply(&TM0, &TM0, &TM2);
	D3DXMatrixMultiply(&TM0, &TM0, &TM3);

	g_pd3dDevice->SetTransform(D3DTS_WORLD, &TM0);
	g_pd3dDevice->DrawIndexedPrimitive(D3DPT_TRIANGLELIST, 0, 0, 24, 0, 12);
}

void Drawsky()
{
	D3DXMATRIX cloudm_0;
	D3DXMatrixIdentity(&cloudm_0);
	// D3DXMatrixIdentity : ����� ������ �� ��� �ӽ� ���� ä��� �ڵ�

	cloudm_0._11 = tempViewTM._11;
	cloudm_0._13 = tempViewTM._13;
	cloudm_0._31 = tempViewTM._31;
	cloudm_0._33 = tempViewTM._33;
	D3DXMatrixInverse(&cloudm_0, NULL, &cloudm_0);
	// D3DXMatrixInverse : ����� �Լ�

	g_pd3dDevice->SetStreamSource(0, air, 0, sizeof(CUSTOMVERTEX));
	g_pd3dDevice->SetIndices(cloud);
	g_pd3dDevice->SetTexture(0, g_ppTexture2);

	for (int i = 0; i < 10; i++)
	{
		cloudm_0._41 = -i +5;
		cloudm_0._42 = i -5;
		cloudm_0._43 = i -5;

		g_pd3dDevice->SetTransform(D3DTS_WORLD, &cloudm_0);
		g_pd3dDevice->DrawIndexedPrimitive(D3DPT_TRIANGLELIST, 0, 0, 4, 0, 2);
	}
}


VOID Render()
{
	if (NULL == g_pd3dDevice)
		return;

	g_pd3dDevice->Clear(0, NULL, D3DCLEAR_TARGET | D3DCLEAR_ZBUFFER, D3DCOLOR_XRGB(130, 200, 255), 1.0f, 0);

	if (SUCCEEDED(g_pd3dDevice->BeginScene()))
	{
		D3DXMATRIX tempTM0, tempTM2;
		D3DXMATRIX tempTM0_0, tempTM0_1, tempTM2_0, tempTM2_1;

		D3DXMATRIX turn;
		D3DXMatrixRotationYawPitchRoll(&turn, -tx, ty, tz);

		// ī�޶�
		D3DXVECTOR3 v3Eye(Player.x, Player.y + 0.5f, Player.z - 1.0f);
		D3DXVECTOR3 v3LookAt(Player.x, Player.y, Player.z);
		D3DXVECTOR3 v3Up(0.0f, 1.0f, 0.0f);
		D3DXMatrixLookAtLH(&tempViewTM, &v3Eye, &v3LookAt, &v3Up);

		D3DXMatrixMultiply(&tempViewTM, &tempViewTM, &turn);
		g_pd3dDevice->SetTransform(D3DTS_VIEW, &tempViewTM);

		// �� ũ��
		D3DXMATRIX tempProjection;
		D3DXMatrixPerspectiveFovLH(&tempProjection, 2.0f, 1.0f, 0.001f, 100.0f);
		g_pd3dDevice->SetTransform(D3DTS_PROJECTION, &tempProjection);

		// UI
		DXUT_SCREEN_VERTEX UIvertices[4] =
		{
			300.0f, 50.0f, 0.0f, 1.0f, 0xffffEB46, 0, 0,
			10.0f, 50.0f, 0.0f, 1.0f, 0xffff6633, 0, 0,
			10.0f, 10.0f, 0.0f, 1.0f, 0xffff6633, 0, 0,
			300.0f, 10.0f, 0.0f, 1.0f, 0xffffEB46, 0, 0,
		};
		g_pd3dDevice->SetFVF(DXUT_SCREEN_VERTEX::FVF);
		g_pd3dDevice->DrawPrimitiveUP(D3DPT_TRIANGLEFAN, 2, UIvertices, sizeof(DXUT_SCREEN_VERTEX));

		g_pd3dDevice->SetStreamSource(0, g_pVB, 0, sizeof(CUSTOMVERTEX));
		g_pd3dDevice->SetFVF(D3DFVF_CUSTOMVERTEX);
		g_pd3dDevice->SetIndices(g_pIB);
		g_pd3dDevice->SetTexture(0, g_ppTexture);

		DrawLight();

		D3DXMatrixTranslation(&tempTM0, 0.3f, 0.1f, 0.2f);
		g_pd3dDevice->SetTransform(D3DTS_WORLD, &tempTM0);
		g_pd3dDevice->DrawIndexedPrimitive(D3DPT_TRIANGLELIST, 0, 0, 24, 0, 12);
		D3DXMatrixTranslation(&tempTM0_0, -1.2f, 0.3f, -0.5f);
		g_pd3dDevice->SetTransform(D3DTS_WORLD, &tempTM0_0);
		g_pd3dDevice->DrawIndexedPrimitive(D3DPT_TRIANGLELIST, 0, 0, 24, 0, 12);
		D3DXMatrixTranslation(&tempTM0_1, 0.3f, 0.1f, -3.0f);
		g_pd3dDevice->SetTransform(D3DTS_WORLD, &tempTM0_1);
		g_pd3dDevice->DrawIndexedPrimitive(D3DPT_TRIANGLELIST, 0, 0, 24, 0, 12);

		DrawPlayer();
		Drawsky();

		g_pd3dDevice->SetStreamSource(0, g_pVB, 0, sizeof(CUSTOMVERTEX));
		g_pd3dDevice->SetIndices(g_pIB);
		g_pd3dDevice->SetTexture(0, g_ppTexture1);

		D3DXMatrixTranslation(&tempTM2, -0.5f, -0.3f, 0.4f);
		g_pd3dDevice->SetTransform(D3DTS_WORLD, &tempTM2);
		g_pd3dDevice->DrawIndexedPrimitive(D3DPT_TRIANGLELIST, 0, 0, 24, 0, 12);
		D3DXMatrixTranslation(&tempTM2_0, 2.0f, -1.0f, -0.9f);
		g_pd3dDevice->SetTransform(D3DTS_WORLD, &tempTM2_0);
		g_pd3dDevice->DrawIndexedPrimitive(D3DPT_TRIANGLELIST, 0, 0, 24, 0, 12);
		D3DXMatrixTranslation(&tempTM2_1, 1.0f, -0.3f, -2.4f);
		g_pd3dDevice->SetTransform(D3DTS_WORLD, &tempTM2_1);
		g_pd3dDevice->DrawIndexedPrimitive(D3DPT_TRIANGLELIST, 0, 0, 24, 0, 12);

		g_pd3dDevice->EndScene();
	}

	g_pd3dDevice->Present(NULL, NULL, NULL, NULL);
}

HRESULT InitIB()
{
	//{
	//	{0.25f, -0.25f, 0.3f,0,0,0, 0.0f, 0.0f,}, 
	//	{-0.25f,-0.25f, 0.3f,0,0,0, 0.0f, 0.5f,}, 
	//	{-0.25f, 0.25f, 0.3f,0,0,0, 0.33f, 0.5f,},
	//	{0.25f, 0.25f, 0.3f,0,0,0, 0.33f, 0.0f,},

	//	{-0.25f, -0.25f, 0.8f,0,0,0, 0.0f, 0.5f,},
	//	{0.25f,-0.25f, 0.8f,0,0,0, 0.0f, 1.0f,},
	//	{0.25f, 0.25f, 0.8f,0,0,0, 0.33f, 1.0f,},
	//	{-0.25f, 0.25f, 0.8f,0,0,0, 0.33f, 0.5f,},

	//	{0.25f, 0.25f, 0.8f,0,0,0, 0.33f, 0.0f,},
	//	{0.25f,-0.25f, 0.8f,0,0,0, 0.33f, 0.5f,},
	//	{0.25f,-0.25f, 0.3f,0,0,0, 0.66f, 0.5f,},
	//	{0.25f, 0.25f, 0.3f,0,0,0, 0.66f, 0.0f,},

	//	{0.25f, -0.25f, 0.8f,0,0,0, 0.33f, 0.5f,},
	//	{-0.25f, -0.25f, 0.8f,0,0,0, 0.33f, 1.0f,},
	//	{-0.25f, -0.25f, 0.3f,0,0,0, 0.66f, 1.0f,},
	//	{0.25f, -0.25f, 0.3f,0,0,0, 0.66f, 0.5f,},

	//	{-0.25f, -0.25f, 0.8f,0,0,0, 0.66f, 0.0f,},
	//	{-0.25f, 0.25f, 0.8f,0,0,0, 0.66f, 0.5f,},
	//	{-0.25f, 0.25f, 0.3f,0,0,0, 1.0f, 0.5f,},
	//	{-0.25f, -0.25f, 0.3f,0,0,0, 1.0f, 0.0f,},

	//	{-0.25f, 0.25f, 0.8f,0,0,0, 0.66f, 0.5f,},
	//	{0.25f, 0.25f, 0.8f,0,0,0, 0.66f, 1.0f,},
	//	{0.25f, 0.25f, 0.3f,0,0,0, 1.0f, 1.0f,},
	//	{-0.25f, 0.25f, 0.3f,0,0,0, 1.0f, 0.5f,},
	//};

	CUSTOMVERTEX vertices[] =
	{
	vertices[0].position = D3DXVECTOR3(0.25f, -0.25f, 0.3f),
	vertices[0].normal = D3DXVECTOR3(0.0f, 0.0f, 0.0f),
	vertices[0].tu = 0.0f, vertices[0].tv = 0.0f,
	vertices[1].position = D3DXVECTOR3(-0.25f, -0.25f, 0.3f),
	vertices[1].normal = D3DXVECTOR3(0.0f, 0.0f, 0.0f),
	vertices[1].tu = 0.0f, vertices[1].tv = 0.5f,
	vertices[2].position = D3DXVECTOR3(-0.25f, 0.25f, 0.3f),
	vertices[2].normal = D3DXVECTOR3(0.0f, 0.0f, 0.0f),
	vertices[2].tu = 0.33f, vertices[2].tv = 0.5f,
	vertices[3].position = D3DXVECTOR3(0.25f, 0.25f, 0.3f),
	vertices[3].normal = D3DXVECTOR3(0.0f, 0.0f, 0.0f),
	vertices[3].tu = 0.33f, vertices[3].tv = 0.0f,

	vertices[4].position = D3DXVECTOR3(-0.25f, -0.25f, 0.8f),
	vertices[4].normal = D3DXVECTOR3(0.0f, 0.0f, 0.0f),
	vertices[4].tu = 0.0f, vertices[4].tv = 0.5f,
	vertices[5].position = D3DXVECTOR3(0.25f, -0.25f, 0.8f),
	vertices[5].normal = D3DXVECTOR3(0.0f, 0.0f, 0.0f),
	vertices[5].tu = 0.0f, vertices[5].tv = 1.0f,
	vertices[6].position = D3DXVECTOR3(0.25f, 0.25f, 0.8f),
	vertices[6].normal = D3DXVECTOR3(0.0f, 0.0f, 0.0f),
	vertices[6].tu = 0.33f, vertices[6].tv = 1.0f,
	vertices[7].position = D3DXVECTOR3(-0.25f, 0.25f, 0.8f),
	vertices[7].normal = D3DXVECTOR3(0.0f, 0.0f, 0.0f),
	vertices[7].tu = 0.33f, vertices[7].tv = 0.5f,

	vertices[8].position = D3DXVECTOR3(0.25f, 0.25f, 0.8f),
	vertices[8].normal = D3DXVECTOR3(0.0f, 0.0f, 0.0f),
	vertices[8].tu = 0.33f, vertices[8].tv = 0.0f,
	vertices[9].position = D3DXVECTOR3(0.25f, -0.25f, 0.8f),
	vertices[9].normal = D3DXVECTOR3(0.0f, 0.0f, 0.0f),
	vertices[9].tu = 0.33f, vertices[9].tv = 0.5f,
	vertices[10].position = D3DXVECTOR3(0.25f, -0.25f, 0.3f),
	vertices[10].normal = D3DXVECTOR3(0.0f, 0.0f, 0.0f),
	vertices[10].tu = 0.66f, vertices[10].tv = 0.5f,
	vertices[11].position = D3DXVECTOR3(0.25f, 0.25f, 0.3f),
	vertices[11].normal = D3DXVECTOR3(0.0f, 0.0f, 0.0f),
	vertices[11].tu = 0.66f, vertices[11].tv = 0.0f,

	vertices[12].position = D3DXVECTOR3(0.25f, -0.25f, 0.8f),
	vertices[12].normal = D3DXVECTOR3(0.0f, 0.0f, 0.0f),
	vertices[12].tu = 0.33f, vertices[12].tv = 0.5f,
	vertices[13].position = D3DXVECTOR3(-0.25f, -0.25f, 0.8f),
	vertices[13].normal = D3DXVECTOR3(0.0f, 0.0f, 0.0f),
	vertices[13].tu = 0.33f, vertices[13].tv = 1.0f,
	vertices[14].position = D3DXVECTOR3(-0.25f, -0.25f, 0.3f),
	vertices[14].normal = D3DXVECTOR3(0.0f, 0.0f, 0.0f),
	vertices[14].tu = 0.66f, vertices[14].tv = 1.0f,
	vertices[15].position = D3DXVECTOR3(0.25f, -0.25f, 0.3f),
	vertices[15].normal = D3DXVECTOR3(0.0f, 0.0f, 0.0f),
	vertices[15].tu = 0.66f, vertices[15].tv = 0.5f,

	vertices[16].position = D3DXVECTOR3(-0.25f, -0.25f, 0.8f),
	vertices[16].normal = D3DXVECTOR3(0.0f, 0.0f, 0.0f),
	vertices[16].tu = 0.66f, vertices[16].tv = 0.0f,
	vertices[17].position = D3DXVECTOR3(-0.25f, 0.25f, 0.8f),
	vertices[17].normal = D3DXVECTOR3(0.0f, 0.0f, 0.0f),
	vertices[17].tu = 0.66f, vertices[17].tv = 0.5f,
	vertices[18].position = D3DXVECTOR3(-0.25f, 0.25f, 0.3f),
	vertices[18].normal = D3DXVECTOR3(0.0f, 0.0f, 0.0f),
	vertices[18].tu = 1.0f, vertices[18].tv = 0.5f,
	vertices[19].position = D3DXVECTOR3(-0.25f, -0.25f, 0.3f),
	vertices[19].normal = D3DXVECTOR3(0.0f, 0.0f, 0.0f),
	vertices[19].tu = 1.0f, vertices[19].tv = 0.0f,

	vertices[20].position = D3DXVECTOR3(-0.25f, 0.25f, 0.8f),
	vertices[20].normal = D3DXVECTOR3(0.0f, 0.0f, 0.0f),
	vertices[20].tu = 0.66f, vertices[20].tv = 0.5f,
	vertices[21].position = D3DXVECTOR3(0.25f, 0.25f, 0.8f),
	vertices[21].normal = D3DXVECTOR3(0.0f, 0.0f, 0.0f),
	vertices[21].tu = 0.66f, vertices[21].tv = 1.0f,
	vertices[22].position = D3DXVECTOR3(0.25f, 0.25f, 0.3f),
	vertices[22].normal = D3DXVECTOR3(0.0f, 0.0f, 0.0f),
	vertices[22].tu = 1.0f, vertices[22].tv = 1.0f,
	vertices[23].position = D3DXVECTOR3(-0.25f, 0.25f, 0.3f),
	vertices[23].normal = D3DXVECTOR3(0.0f, 0.0f, 0.0f),
	vertices[23].tu = 1.0f, vertices[23].tv = 0.5f,
	};

	WORD index[] =
	{
		0,1,2,
		0,2,3,

		4,5,6,
		4,6,7,

		8,9,10,
		8,10,11,

		12,13,14,
		12,14,15,

		16,17,18,
		16,18,19,

		20,21,22,
		20,22,23,
	};

	//{
	//	{0.25f, -0.25f, 0.3f,0,0,0, 0.45f, 0.3f,},
	//	{-0.25f,-0.25f, 0.3f,0,0,0, 0.0f, 0.3f,},
	//	{-0.25f, 0.25f, 0.3f,0,0,0, 0.0f, 0.05f,},
	//	{0.25f, 0.25f, 0.3f,0,0,0, 0.45f, 0.05f,},
	//};

	CUSTOMVERTEX air_0[] = 
	{
	air_0[0].position = D3DXVECTOR3(0.25f, -0.25f, 0.3f),
	air_0[0].normal = D3DXVECTOR3(0.0f, 0.0f, 0.0f),
    air_0[0].tu = 0.0f, air_0[0].tv = 1.0f,
	air_0[1].position = D3DXVECTOR3(-0.25f, -0.25f, 0.3f),
	air_0[1].normal = D3DXVECTOR3(0.0f, 0.0f, 0.0f),
	air_0[1].tu = 1.0f, air_0[1].tv = 1.0f,
	air_0[2].position = D3DXVECTOR3(-.25f, 0.25f, 0.3f),
	air_0[2].normal = D3DXVECTOR3(0.0f, 0.0f, 0.0f),
	air_0[2].tu = 1.0f, air_0[2].tv = 0.0f,
	air_0[3].position = D3DXVECTOR3(0.25f, 0.25f, 0.3f),
	air_0[3].normal = D3DXVECTOR3(0.0f, 0.0f, 0.0f),
	air_0[3].tu = 0.0f, air_0[3].tv = 0.0f,
	};

	WORD sky[] =
	{
		0,1,2,
		0,2,3,
	};

	D3DXVECTOR3 pNormal, p1, p2;

	for (int i = 0; i < 21; i += 4)
	{
		p1 = vertices[i+1].position - vertices[i].position;
		p2 = vertices[i+2].position - vertices[i].position;
		D3DXVec3Cross(&pNormal, &p2, &p1);

		vertices[i].normal = pNormal;
		vertices[i+1].normal = pNormal;
		vertices[i+2].normal = pNormal;

		p1 = vertices[i+2].position - vertices[i].position;
		p2 = vertices[i+3].position - vertices[i].position;
		D3DXVec3Cross(&pNormal, &p2, &p1);

		vertices[i+3].normal = pNormal;
	}

	p1 = air_0[1].position - air_0[0].position;
	p2 = air_0[2].position - air_0[0].position;
	D3DXVec3Cross(&pNormal, &p2, &p1);

	air_0[0].normal = pNormal;
	air_0[1].normal = pNormal;
	air_0[2].normal = pNormal;

	p1 = air_0[2].position - air_0[0].position;
	p2 = air_0[3].position - air_0[0].position;
	D3DXVec3Cross(&pNormal, &p2, &p1);

	air_0[3].normal = pNormal;

	g_pd3dDevice->CreateVertexBuffer(sizeof(vertices) * sizeof(CUSTOMVERTEX),0,D3DFVF_CUSTOMVERTEX,
		D3DPOOL_DEFAULT,&g_pVB,NULL);

	g_pd3dDevice->CreateIndexBuffer(sizeof(index) * sizeof(WORD),0,D3DFMT_INDEX16,
		D3DPOOL_DEFAULT,&g_pIB,NULL);

	g_pd3dDevice->CreateVertexBuffer(sizeof(air_0) * sizeof(CUSTOMVERTEX), 0, D3DFVF_CUSTOMVERTEX,
		D3DPOOL_DEFAULT, &air, NULL);

	g_pd3dDevice->CreateIndexBuffer(sizeof(sky) * sizeof(WORD), 0, D3DFMT_INDEX16,
		D3DPOOL_DEFAULT, &cloud, NULL);

	VOID* pVertices;

	g_pVB->Lock(0, sizeof(vertices), (void**)&pVertices, 0);
	memcpy(pVertices, vertices, sizeof(vertices));
	g_pVB->Unlock();

	VOID* pIndices;

	g_pIB->Lock(0, sizeof(index), (void**)&pIndices, 0);
	memcpy(pIndices, index, sizeof(index));
	g_pIB->Unlock();

	VOID* p_air;

	air->Lock(0, sizeof(air_0), (void**)&p_air, 0);
	memcpy(p_air, air_0, sizeof(air_0));
	air->Unlock();

	VOID* up;

	cloud->Lock(0, sizeof(sky), (void**)&up, 0);
	memcpy(up, sky, sizeof(sky));
	cloud->Unlock();


	D3DXCreateTextureFromFile(g_pd3dDevice,"Dice.bmp",&g_ppTexture);
	D3DXCreateTextureFromFile(g_pd3dDevice,"64885.bmp",&g_ppTexture1);
	D3DXCreateTextureFromFile(g_pd3dDevice, "cloud.bmp", &g_ppTexture2);

	// ����̽� ���������� ó���Ұ�� ���⿡�� �Ѵ�.
	return S_OK;
}

LRESULT WINAPI MsgProc(HWND hWnd, UINT msg, WPARAM wParam, LPARAM lParam)
{
	switch (msg)
	{
	case WM_DESTROY:
		Cleanup();
		PostQuitMessage(0);
		return 0;
	case WM_PAINT:
		Render();
		ValidateRect(hWnd, NULL);
		return 0;
	}
	return DefWindowProc(hWnd, msg, wParam, lParam);
}


/*------------------------------------------------------------------------------
 * �� ���α׷��� ������
 *------------------------------------------------------------------------------
 */
INT WINAPI WinMain(HINSTANCE hInst, HINSTANCE, LPSTR, INT)
{
	// ������ Ŭ���� ���
	WNDCLASSEX wc = { sizeof(WNDCLASSEX), CS_CLASSDC, MsgProc, 0L, 0L,
					  GetModuleHandle(NULL), NULL, NULL, NULL, NULL,
					  "D3DBeta", NULL };
	RegisterClassEx(&wc);
	// ������ ����
	HWND hWnd = CreateWindow("D3DBeta", "Test",
		WS_OVERLAPPEDWINDOW, 300, 300, 1000, 500,
		GetDesktopWindow(), NULL, wc.hInstance, NULL);
	// Direct3D �ʱ�ȭ
	if (SUCCEEDED(InitD3D(hWnd)) && SUCCEEDED(InitIB()))
	{
		// ������ ���
		ShowWindow(hWnd, SW_SHOWDEFAULT);
		UpdateWindow(hWnd);
		// �޽��� ����
		MSG msg;
		while (TRUE)
		{
			if (PeekMessage(&msg, NULL, 0, 0, PM_REMOVE))
			{
				if (msg.message == WM_QUIT) break;
				TranslateMessage(&msg);
				DispatchMessage(&msg);
			}
			else
			{
				__KeyProc();
				Render();
			}
		}
	}

	// ��ϵ� Ŭ���� �Ұ�
	UnregisterClass("D3DBeta", wc.hInstance);
	return 0;
}
void __KeyProc()
{
	//// 0x80 ��Ʈ�� 1�̸� ����Ű�� ���� ��
	//   ���� 0x80 ��Ʈ�� 1�̾��ٰ� 0�� �Ǹ� ����Ű�� �� ��
	//   (0x80 ��Ʈ�� 0�� ���°� ����Ű�� �� ���� �ƴԿ� ����)
	// 0x80 == 0b1000 0000
	if (GetKeyState(VK_LEFT) & 0x80 || GetKeyState(0x41) & 0x80) Direction.x -= 0.005f;
	if (GetKeyState(VK_RIGHT) & 0x80 || GetKeyState(0x44) & 0x80) Direction.x += 0.005f;
	if (GetKeyState(VK_UP) & 0x80 || GetKeyState(0x57) & 0x80) Direction.z += 0.005f;
	if (GetKeyState(VK_DOWN) & 0x80 || GetKeyState(0x53) & 0x80) Direction.z -= 0.005f;
	//if (GetKeyState(VK_HOME) & 0x80 || GetKeyState(0x45) & 0x80) Direction.y -= 0.005f;
	//if (GetKeyState(VK_END) & 0x80 || GetKeyState(0x51) & 0x80) Direction.y += 0.005f;

	if (GetKeyState(VK_NUMPAD4) & 0x80)tx -= 0.05f;
	if (GetKeyState(VK_NUMPAD6) & 0x80)tx += 0.05f;
	if (GetKeyState(VK_NUMPAD8) & 0x80)ty -= 0.05f;
	if (GetKeyState(VK_NUMPAD5) & 0x80)ty += 0.05f;
	//if (GetKeyState(VK_NUMPAD9) & 0x80)tz -= 0.05f;
	//if (GetKeyState(VK_NUMPAD7) & 0x80)tz += 0.05f;
	if (GetKeyState(VK_SPACE) & 0x80)
	{
		Player = { 0,0,0 };
		Direction *= 0;
		tx = ty = tz = 0;
	}

	Direction *= 0.95f;
}